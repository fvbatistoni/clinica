Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/multiple-image-upload-view-edit-delete-in-php/

============ Instructions ============
1. Create a database (for example, codexworld) and import the "SQL/gallery_crud.sql" file into this database.
2. Open the "DB.class.php" file ==> Specify the database host ($dbHost), username ($dbUsername), password ($dbPassword), and name ($dbName) as per your MySQL server credentials.
3. Open the "index.php" file on the browser ==> Test the Multiple Image Upload management functionality.


============ May I Help You ===========
If you have any questions about this script, send us by posting comment here - http://www.codexworld.com/multiple-image-upload-view-edit-delete-in-php/#respond.